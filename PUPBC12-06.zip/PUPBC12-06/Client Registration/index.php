<?php 

include '../db/connection.php';

if($_SERVER['REQUEST_METHOD'] == "POST")
{
    $stud_num = $_POST['stud_num'];
    $stud_pass = $_POST['password'];
    $stud_name = $_POST['stud_name'];
    $stud_email = $_POST['stud_email'];
    $stud_contact = $_POST['stud_contact'];
    $guardian = $_POST['stud_guardian'];
    $guardian_contact = $_POST['guardian_contact'];

    if(!empty($stud_num) && !empty($stud_pass) && !empty($stud_name) && 
    !empty($stud_email) && !empty($stud_contact) && !empty($guardian) && !empty($guardian_contact))
    {
        $query = "INSERT INTO tbl_clients(stud_num, stud_pass, stud_name,
        stud_email, stud_contact, stud_guardian, guardian_contact) VALUES ('$stud_num', '$stud_pass',
        '$stud_name', '$stud_email', '$stud_contact', '$guardian', '$guardian_contact',)";

        mysqli_query($conn, $query);
        header("Location:../Client");
        die;
    }else
    {
        echo "Please fill out the missing details";
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!---icon--->
    <script src="https://kit.fontawesome.com/dcd5bb0e38.js" crossorigin="anonymous"></script> <!---icon--->

    <link href="assets/css/reg_style.css" rel="stylesheet">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Registration</title>
</head>
<body>
    <div class="select_container">

        <div class="selection">
            <a class="back_bttn" href="../Client Login/"><i class="fas fa-arrow-left"></i></a>

            <div class="reg_form">
                <div class="title">
                    <h1>Client Registration</h1>
                    <hr>
                </div>

                <form method="POST">
                    <div class="input_group">
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Student Number" name="stud_num">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="password" placeholder="Student Password" name="password">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="password" placeholder="Confirm Password" name="password2">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Full Name" name="stud_name">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Email Address" name="stud_email">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Contact Number" name="stud_contact">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Guardian's Name" name="stud_guardian">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Guardian's Contact Number" name="guardian_contact">
                            <i class="fas fa-lock"></i>
                        </div>
                    <div class="bttn_group">
                        <div class="reg_bttn">
                            <button type="submit" name="submit" class="selection_bttn"><i class="fas fa-sign-in-alt"></i> Sign Up</button>
                        </div>
                    </div>
               </form>
            </div>
            
            
            

        </div>

    </div>
    
</body>
</html>