<?php
    $title = 'Maintenance';
    $page = 'v_maintenance';
    include_once('../includes/header.php');
?>

<?php
    $sub_page = 'vmain_stud_main';
    include('../includes/sub_nav.php');
?>
<?php 
    include 'assets/dbconnection.php';
    $query = "SELECT * from forprogram";

    $result1 = mysqli_query($conn, $query);
    $options = "";
    while($row2 = mysqli_fetch_array($result1))
    {
        $options = $options."<option>$row2[1]</option>";
    }
    // Year and section
    
    $query2 = "SELECT yearFrom, yearTo, Semester from foracademicyear";

    $result2 = mysqli_query($conn, $query2);
    $options2 = "";
    while($row3 = mysqli_fetch_array($result2))
    {
        $options2 = $options2."<option>$row3[0] - $row3[1], $row3[2] Semester</option>";
    }

?>
            <div class="subcontent">
                <div class="sub_nav">
                    <a href="../Violation Maintenance Student Maintenance/" class="sub_nav_bttn">
                        Update Student
                    </a>
                    <a href="../Violation Maintenance Student Maintenance Section Year/" class="sub_nav_bttn">
                        Update Section/Year
                    </a>
                    <a href="../Violation Maintenance Student Maintenance Status/" class="sub_nav_bttn_active">
                        Update Status
                    </a>
                </div>

                <!-- Update Status Tab -->
                <div class="sub_top_content">
                    <div class="student_input_group">

                        <div class="student_select">
                            <label for="#" class="label">Year and Section: </label>
                            <select class="curri_selection" name="#" id="#">
                                <?php echo $options2; ?>
                            </select>
                        </div>
                        
                        <div class="student_select">
                            <label for="#" class="label">Curriculum: </label>
                            <select class="curri_selection" name="#" id="#">
                                <?php echo $options; ?>
                            </select>
                        </div>
                    </div>

                    <div class="stud_left_group">

                        <div class="student_select">
                            <label for="#" class="label">Status: </label>
                            <select class="curri_selection" name="#" id="#">
                                <option value="#">Enable</option>
                                <option value="#">Disable</option>
                            </select>
                        </div>

                        <div class="student_main_bttn_group">
                            
                            <a href="#" class="stud_bttn">
                                <i class="fas fa-save"></i>
                                Delete all Disable
                            </a>
                            <a href="#" class="stud_bttn">
                                <i class="fas fa-save"></i>
                                Disable All
                            </a>
                            <a href="#" class="stud_bttn">
                                <i class="fas fa-save"></i>
                                Update
                            </a>
                        </div>
                    </div>
                    
                </div>
                    

                <div class="stud_table_content">
                    <table class="stud_table">
                        <tr> 
                            <th class="stud_title"> </th>
                            <th class="stud_title">No.</th>
                            <th class="stud_title">Student #</th>
                            <th class="stud_title">Curriculum</th>
                            <th class="stud_title">Section</th>
                        </tr>
                        <tr>
                            <td class="stud_data"> </td>
                            <td class="stud_data"> </td>
                            <td class="stud_data"> </td>
                            <td class="stud_data"> </td>
                            <td class="stud_data"> </td>
                        </tr>
                    </table>
                </div>

            </div>
      
        </div>
    </div>


</body>

</html>