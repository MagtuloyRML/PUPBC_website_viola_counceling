    <!---Modal/ Pop up-->
    <div class="modal_bg studDetails" id="modal_add_student">
        <div class="modal">
            <div class="title_bar">
                <p>Student Details</p>
                <a href="#" class="modal_title_bttn" id="close_modal" ><i class="fas fa-times-circle"></i></a>
            </div>
            <!--<form>-->
                <div class="modal_content">
                    <div class="modal_studDetails_input_container">
                        <div class="input_sd">
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <input type="text" class="input_field" id="#" name="#" class="">
                            </div>
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <input type="text" class="input_field" id="#" name="#" class="">
                            </div>
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <input type="text" class="input_field" id="#" name="#" class="">
                            </div>
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <input type="text" class="input_field" id="#" name="#" class="">
                            </div>
                        </div>
                        
                        <div class="input_sd">
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <select class="input_field" name="#" id="#">
                                    <option value="#"> </option>
                                    <option value="#"> </option>
                                </select>
                            </div>
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <input type="text" class="input_field" id="#" name="#" class="">
                            </div>
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <input type="text" class="input_field" id="#" name="#" class="">
                            </div>
                            <div class="modal_studDetails_input">
                                <p class="label">AY CODE: </p>
                                <select class="input_field" name="#" id="#">
                                    <option value="#"> </option>
                                    <option value="#"> </option>
                                </select>
                            </div>
                        </div>
                        
                    </div>
                    
                    
                </div>

                <div class="footer_modal_bttn">
                    <a href="#" class="modal_foot_bttn"><i class="fas fa-save"></i> Save</a>
                    <a href="#" id="close_modal2" class="modal_foot_bttn"><i class="fas fa-sign-out-alt"></i> Exit</a>
                </div>

            <!--</form>-->
            
        </div>
    </div>

    <script src="assets/js/modal_add_student.js"></script>
