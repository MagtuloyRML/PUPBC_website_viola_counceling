<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!---icon--->
    <script src="https://kit.fontawesome.com/dcd5bb0e38.js" crossorigin="anonymous"></script> <!---icon--->

    <link href="assets/css/login_style.css" rel="stylesheet">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Login</title>
</head>
<body>
    <div class="body_content">
        <a class="back_bttn" href="../index.php"><i class="fas fa-arrow-left"></i></a>
        <div class="welcome_text">
            <img class="logo" src="assets/img/1200px-Polytechnic_University_of_the_Philippines_Biñan_Logo.svg.png" alt="PUPBC LOGO">
            <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                Aenean fringilla nec ante vel vestibulum.
            </p>
        </div>

        <div class="login_form">
            <form action="admin_login_work.php" method="POST">
                <div class="input_group">
                    <div class="input_container">
                        <input class="input-field" type="text" placeholder="Username" name="username">
                        <i class="fas fa-user-tie"></i>
                    </div>

                    <div class="input_container">
                        <input class="input-field" type="password" placeholder="Password" name="password">
                        <i class="fas fa-lock"></i>
                    </div>
                </div>
                <?php
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<span>$error</span>";
                    }
                ?>  
                <div class="bttn_group">
                    <div class="login_bttn">
                        <button type="submit" name="submit" class="selection_bttn"><i class="fas fa-sign-in-alt"></i> Login</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    
</body>
</html>
<?php
    unset($_SESSION["error"]);
?>