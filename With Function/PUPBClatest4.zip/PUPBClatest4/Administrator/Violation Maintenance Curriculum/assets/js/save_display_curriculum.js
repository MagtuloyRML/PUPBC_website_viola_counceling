<script>
    document.getElementById('saveBttn').addEventListener('click' function(){
    document
    })
</script>