<?php
    // INSERTING THE DATA TO DATA BASE
        include 'dbconnection.php';
    
        if(isset($_POST['submit'])){
        $studNum = $_POST['studNum'];
        $lastName = $_POST['lastName'];
        $firstName = $_POST['firstName'];
        $middleName = $_POST['middleName'];
        $Course = $_POST['Course'];
        $Section = $_POST['Section'];
        $Address = $_POST['Address'];
        $Gender = $_POST['Gender'];
        
        $sql = "INSERT INTO forstudents (studNum, lastName, firstName, middleName, Course, Section, Addres, Gender) 
        VALUES ('$studNum', '$lastName', '$firstName','$middleName','$Course','$Section','$Address','$Gender')";
        $result = mysqli_query($conn, $sql);
    
    
        if(!$result){
    
            echo "Failed". $sql . $conn -> error;
            location("header: ../index.php");
        }else{
            echo "Saved successfully";
            location("header: ../index.php");
        }
    }
            
        

        
    

     
   
        
        
    

    