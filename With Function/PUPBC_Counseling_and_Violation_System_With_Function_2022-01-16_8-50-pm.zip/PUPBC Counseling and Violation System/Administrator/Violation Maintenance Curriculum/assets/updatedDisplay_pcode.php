<?php
    include_once 'dbconnection.php';

    $SQL = ("SELECT courseCode, courseDescription FROM forprogram");
    $RESULT = mysqli_query($conn, $SQL);
    $resultchecker = mysqli_num_rows($RESULT);

    if ($resultchecker > 0) {
        ?>
        <tr>
            <th class="curriculum_title">CCode</th>
            <th class="curriculum_title">Description</th>
            <th class="curriculum_title"> </th>
            <th class="curriculum_title"> </th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($RESULT)) {
            ?>
            <tr id="editRows">
                <td class="curriculum_data" ><?php echo $row['courseCode']."<br>";?></td>
                <td class="curriculum_data" > <?php  echo $row['courseDescription'] ."<br>";?> </td>
                <td class="curriculum_data" > <a href="assets/delete_program.php?courseCode=<?php echo $row['courseCode']."<br>"; ?>" class="c_data_bttn" ><i class="fas fa-trash-alt"></i></a></td>
                <td class="curriculum_data" > <a  href="assets/edit.php?courseCode=<?php echo $row['courseCode']."<br>"; ?>" class="c_data_bttn" ><i class="fas fa-edit"></i></a></td>
            </tr>        
            <?php
        }
            
    }
?>