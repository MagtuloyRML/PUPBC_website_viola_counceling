    <!---Modal/ Pop up-->
    <div class="modal_upload_bg" id="modal_upload_student">
        <div class="modal_upload">
            <div class="title_bar">
                <p>Upload Preview</p>
                <a href="#" class="modal_title_bttn" id="close_modal0" ><i class="fas fa-times-circle"></i></a>
            </div>
            <!--<form>-->
                <div class="modal_content">
                        
                        <div class="preview_table_content">
                            <table class="preview_table">
                                <tr> 
                                    <th class="preview_title"> </th>
                                    <th class="preview_title">Student Num</th>
                                    <th class="preview_title">Last Name</th>
                                    <th class="preview_title">First Name</th>
                                    <th class="preview_title">Middle Name</th>
                                    <th class="preview_title">Curriculum</th>
                                    <th class="preview_title">Section</th>
                                    <th class="preview_title">Address</th>
                                    <th class="preview_title">Gender</th>

                                </tr>
                                <tr>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                    <td class="curriculum_data"> </td>
                                </tr>
                            </table>
                        </div>
                    
                    
                </div>

                <div class="footer_modal_bttn">
                    <a href="#" class="modal_foot_bttn"><i class="fas fa-upload"></i>Upload</a>
                    <a href="#" id="close_modal9" class="modal_foot_bttn"><i class="fas fa-sign-out-alt"></i> Exit</a>
                </div>
            <!--</form>-->
            
            </div>
    </div>

    <script src="assets/js/modal_upload_student.js"></script>