<?php
    $title = 'Counceling Apointment Dashboard';
    $page = 'ca_home';
    include_once('../includes/header.php');
?>
    
</body>

</html>