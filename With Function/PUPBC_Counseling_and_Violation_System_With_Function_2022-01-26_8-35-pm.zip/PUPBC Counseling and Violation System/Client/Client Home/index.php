<?php
    $title = 'Home';
    $page = 'client_home';
    include_once('../includes/header.php');
?>
    <div class="content">
        <div class="home_content">
            <div class="bttn_appoint_list">
                <a href="#" class="appointment_bttn">
                    <i class="fas fa-calendar-check"></i>
                    <span>
                        Appointment
                    </span>
                </a>
                <a href="#" class="appointment_bttn">
                    <i class="fas fa-calendar-check"></i>
                    <span>
                        Appointment
                    </span>
                </a>
                <a href="#" class="appointment_bttn">
                    <i class="fas fa-calendar-check"></i>
                    <span>
                        Appointment
                    </span>
                </a>
                <a href="#" class="appointment_bttn">
                    <i class="fas fa-calendar-check"></i>
                    <span>
                        Appointment
                    </span>
                </a>

            </div>
        </div>

    </div>

</body>

</html>