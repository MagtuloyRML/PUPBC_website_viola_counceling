<?php
    $title = 'Maintenance';
    $page = 'v_maintenance';
    include_once('../includes/header.php');
?>

<?php
    $sub_page = 'vmain_curriculum';
    include('../includes/sub_nav.php');
?>

            <div class="subcontent">
                <div class="title">
                    <h1>Curriculum</h1>
                    <hr>
                </div>

                <div class="c_bttn_group">
                    <a href="#" class="c_bttn" id="upload_bttn">
                        <i class="fas fa-upload"></i>
                        Upload
                    </a>
                    <a href="#" class="c_bttn" id="openModal_add_curriculum">
                        <i class="fas fa-plus-square"></i>
                        Create
                    </a>
                </div>

                <div class="c_table_content">
                    <table class="c_table" id="table">
                        <tr>
                            <th class="curriculum_title">CCode</th>
                            <th class="curriculum_title">Description</th>
                            <th class="curriculum_title"> </th>
                            <th class="curriculum_title"> </th>
                        </tr>
                        <!-- DISPLAYING THE DATA TO WEB PAGE FROM DATA BASE -->
                        <?php
                        include_once 'assets/dbconnection.php';
                        $SQL = $conn->query("SELECT courseCode, courseDescription FROM forprogram");
                
                        if ($SQL->num_rows > 0) {
                            while ($row = $SQL->fetch_assoc()) {
                                ?>
                        <tr id="editRows">
                            <td class="curriculum_data" id="courseCode" ><?php echo $row['courseCode'] ."<br>"; ?></td>
                            <td class="curriculum_data" > <?php  echo $row['courseDescription'] ."<br>";?> </td>
                            <td class="curriculum_data" > <a href="assets/delete_program.php?courseCode=<?php echo $row['courseCode']; ?>" 
                            class="c_data_bttn" ><i class="fas fa-trash-alt"></i></a></td>
                            <td class="curriculum_data" > <a href="modal_edit_curriculum.php?courseCode=<?php echo $row['courseCode']; ?>" 
                            class="c_data_bttn" id="modal_editBTTN" ><i class="fas fa-edit"></i></a></td>
                        </tr>
                                <?php
                            }
                        
                        }
                        ?>
                    </table>
                </div>

            </div>
      
        </div>
    </div>

    <?php
        include('assets/modal_add_curriculum.php');
    ?>
    <?php
        include('assets/modal_upload_curri.php');
    ?>
    
</body>

</html>