<?php
    $title = 'Maintenance';
    $page = 'v_maintenance';
    include_once('../includes/header.php');
?>

<?php
    $sub_page = 'vmain_stud_details';
    include('../includes/sub_nav.php');
?>

            <div class="subcontent">
                <div class="title">
                    <h1>Student Details</h1>
                    <hr>
                </div>

                <div class="sd_bttn_group">
                    <a href="#" class="sd_bttn" id="upload_student_bttn">
                        <i class="fas fa-upload"></i>
                        Upload
                    </a>
                    <a href="#" class="sd_bttn" id="openModal_add_student">
                        <i class="fas fa-plus-square" ></i>
                        Create
                    </a>
                </div>

                <div class="sd_table_content">
                    <table class="sd_table">
                        <tr> 
                            <th class="stud_details_title"> </th>
                            <th class="stud_details_title">No.</th>
                            <th class="stud_details_title">Student Num</th>
                            <th class="stud_details_title">Last Name</th>
                            <th class="stud_details_title">First Name</th>
                            <th class="stud_details_title">Middle Name</th>
                            <th class="stud_details_title">Program</th>
                            <th class="stud_details_title">Sectiom</th>
                            <th class="stud_details_title">Address</th>
                            <th class="stud_details_title">Gender</th>
                        </tr>
                        <tr>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                            <td class="stud_details_data"> </td>
                        </tr>
                    </table>
                </div>

            </div>
    </div>

    <?php
        include_once('assets/modal_add_student.php');
    ?>

<?php
        include_once('assets/modal_upload_student.php');
    ?>

</body>

</html>