<!DOCTYPE html>
<html lang="en">
<head>

    <title>Student Violation Dashboard</title>
</head>
<body>
    
   <div class="DashButtons">
        <table>
            <a href="https://www.facebook.com/"> <input type="button" name="Dashboard" value="DASHBOARD" >  </a>
            <br>
            <a href="https://www.youtube.com/"><input type="button" name="violationEntry" value="VIOLATION ENTRY"> </a> 
            <br>
            <a href="https://www.facebook.com/"><input type="button" name="records" value="RECORDS">  </a>
            <br>
            <a href="https://www.facebook.com/"><input type="button" name="maintenance" value="MAINTENANCE"> </a>
            <br>
            <br>
            <a href="https://www.facebook.com/"><input type="button" name="Logout" value="LOGOUT"></a>
        </table>
    </div>
<center>
    <div class="DashAycode">
        <p>Academic Year</p>
    </div>

    <div class="DashTotalStudent">
        <p>Total Student</p>
    </div>

    <div class="DashTotalViolation">
        <p>Total Violation</p>
    </div>
</center>
</body>
</html>