<?php
    // for Connection.php
    include 'connection.php';
    //pag sinubmit yung sa admin_signup.php
    if(isset($_POST['submit'])){
        $title = $_POST['title'];
        $start_app = $_POST['start_app'];
        $end_app = $_POST['end_app'];
        //insert sa database
        $insert="INSERT INTO `schedules`(`title`, `start_app`,
        `end_app`)
        VALUES ('$title','$start_app','$end_app')";
        if($conn->query($insert)){
            echo "Your Data Inserted"; 
            //header('location:login.php');
            }
            else
            {
                echo "Something is wrong";
            }
    }
?> 
<form method = "POST">
                <p>Fill up the following to appoint a Sched</p>
                <div class="reg_content">
                    <!---Text field for student registration
                    dagdagan mo nyo nalang ng info na need sa system--->
                    <div class="input-container">
                        <i class="fa fa-user icon"></i>
                        <input class="input-field" type="text" placeholder="Title" name="title" value=>
                    </div>
                    <div class="input-container">
                        <i class="fa fa-user icon"></i>
                        <p>Start Date and Time:</p>
                        <input class="input-field" type="datetime-local" name="start_app">
                    </div>
                    <div class="input-container">
                        <i class="fa fa-user icon"></i>
                        <p>End Date and Time:</p>
                        <input class="input-field" type="datetime-local" name="end_app">
                    </div>
                <div class="sign_up">
                    <button type="submit" name="submit" class="btn">Submit</button>
                </div>
                
            </form>
    </div>