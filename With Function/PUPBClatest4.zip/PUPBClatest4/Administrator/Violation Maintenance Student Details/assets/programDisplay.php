<?php 
                                include_once 'dbconnection.php';

                                if (isset($_GET['courseCode'])) {
                                    $courseCode = $_GET['courseCode'];

                                    $sql = "SELECT * FROM forprogram WHERE forprogram . courseCode = '$courseCode'";
                                    if ($result = mysqli_query($conn, $sql)) {
                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_array($result)) {
                                                $dbselected = $row['courseCode'];
                                            }
                                        } else {
                                            echo "Something wrong...";
                                        }
                                    } else {
                                        echo "ERROR";
                                    }
                                }

                                $option = array('Pending');

                                echo " <select class='input_field' name='#' id='#'>";
                                foreach ($option as $option) {
                                    if ($dbselected == $option) {
                                        echo "<option id= 'Course' name='Course' selected='selected' value='$option'> $option </option>";
                                    } else {
                                        echo "<option  value='$option'> $option </option>";
                                    }
                                }

                                echo "</select>"

                                ?>