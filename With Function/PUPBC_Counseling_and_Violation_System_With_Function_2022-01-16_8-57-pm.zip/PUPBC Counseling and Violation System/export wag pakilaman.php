<?php

//import.php

include 'vendor/autoload.php';

$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

if($_FILES["import_excel"]["name"] != '')
{
 $allowed_extension = array('xls', 'csv', 'xlsx');
 $file_array = explode(".", $_FILES["import_excel"]["name"]);
 $file_extension = end($file_array);

 if(in_array($file_extension, $allowed_extension))
 {
  $file_name = time() . '.' . $file_extension;
  move_uploaded_file($_FILES['import_excel']['tmp_name'], $file_name);
  $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
  $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);

  $spreadsheet = $reader->load($file_name);

  unlink($file_name);

  $data = $spreadsheet->getActiveSheet()->toArray();

  foreach($data as $row)
  {
   $insert_data = array(
    ':first_name'  => $row[0],
    ':last_name'  => $row[1],
    ':created_at'  => $row[2],
    ':updated_at'  => $row[3]
   );
   
   $query = "
   INSERT INTO sample_datas 
   (first_name, last_name, created_at, updated_at) 
   VALUES (:first_name, :last_name, :created_at, :updated_at)
   ";

   $statement = $connect->prepare($query);
   $statement->execute($insert_data);
  }
  $message = '<div class="alert alert-success">Data Imported Successfully</div>';

 }
 else
 {
  $message = '<div class="alert alert-danger">Only .xls .csv or .xlsx file allowed</div>';
 }
}
else
{
 $message = '<div class="alert alert-danger">Please Select File</div>';
}

echo $message;



I use this method for skip header :

    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load('FILE.xlsx');
    $sheetData = array();
    
    foreach ($spreadsheet->getWorksheetIterator() as $worksheet) {
        $worksheetTitle = $worksheet->getTitle();
        $highestRow = $worksheet->getHighestRow(); // e.g. 10
        $highestColumn = $worksheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);
    
        for ($row = 1; $row <= $highestRow; ++$row) {
            for ($col = 0; $col <= $highestColumnIndex; ++$col) {
                $cell = $worksheet->getCellByColumnAndRow($col, $row);
                $val = $cell->getValue();
                $sheetData[$row][$col] = $val;
            }
        }
    }
    
    unset($sheetData[1]); // SKIP HEADER
    
    foreach ($sheetData as $val) {
      // set data for upload DB
     }


     $file_name = time() . '.' . $file_extension;
     move_uploaded_file($_FILES['file_path']['tmp_name'], $file_name);
     $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
     $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);

     $spreadsheet = $reader->load($file_name);

     unlink($file_name);

     $data = $spreadsheet->getActiveSheet()->toArray();

     foreach($data as $row)
     {
         $insert_data = array(
             ':pcode'  => $row[0],
             ':description'  => $row[1]
         );
     

         $query = "
         INSERT INTO forprogram
         (courseCode, courseDescription) 
         VALUES (:pcode, :description)
         ";

         $statement = $connect->prepare($query);
         $statement->execute($insert_data);
     }
     $message = '<div class="alert alert-success">Data Imported Successfully</div>';
    

     $checkExistingCode = "SELECT courseCode FROM forprogram WHERE courseCode = '$pcode' ";
            $check = mysqli_query($conn, $checkExistingCode);
            $updatestatement = $conn->prepare($checkExistingCode);
            $updatestatement->execute($insert_data);

            if(mysqli_num_rows($check) > 0){
                $update_data = "UPDATE forprogram SET courseCode = '$pcode', courseDescription = '$description' WHERE courseCode = '$pcode' ";
                $updatestatement = $conn->prepare($update_data);
                $updatestatement->execute($insert_data);
            }
            else{
                $ins_data = "INSERT INTO forprogram (courseCode, courseDescription) VALUES ('$pcode', '$description')";
                $insertstatement = $conn->prepare($ins_data);
                $insertstatement->execute($insert_data);
            }

            $checkExistingCode = "SELECT courseCode FROM forprogram WHERE courseCode = '$pcode' ";
            $check = mysqli_query($conn, $checkExistingCode);
            $updatestatement = $conn->prepare($checkExistingCode);
            $updatestatement->execute($insert_data);

            if(mysqli_num_rows($check) > 0){
                $update_data = "UPDATE forprogram SET courseCode = '$pcode', courseDescription = '$description' WHERE courseCode = '$pcode' ";
                $updatestatement = $conn->prepare($update_data);
                $updatestatement->execute($insert_data);
            }
            else{
                $ins_data = "INSERT INTO forprogram (courseCode, courseDescription) VALUES ('$pcode', '$description')";
                $insertstatement = $conn->prepare($ins_data);
                $insertstatement->execute($insert_data);
            }

            $checkExistingCode = "SELECT courseCode FROM forprogram WHERE courseCode = :pcode ";
            $checkresult = $connect->prepare($checkExistingCode);
            $checkresult->execute($insert_data);
            $result = $checkresult->fetchAll(PDO::FETCH_ASSOC);

            $num_rows = mysqli_num_rows($result);

            if ($num_rows > 0) {
                $update_data = "
                UPDATE forprogram
                SET courseCode = :pcode, 
                courseDescription = :description
                WHERE courseCode = :pcode ";
                $updatestatement = $connect->prepare($update_data);
                $updatestatement->execute($insert_data);
            }
            else{
                $query = "
                INSERT INTO forprogram
                (courseCode, courseDescription) 
                VALUES (:pcode, :description)
                ";

                $statement = $connect->prepare($query);
                $statement->execute($insert_data);
            }
?>