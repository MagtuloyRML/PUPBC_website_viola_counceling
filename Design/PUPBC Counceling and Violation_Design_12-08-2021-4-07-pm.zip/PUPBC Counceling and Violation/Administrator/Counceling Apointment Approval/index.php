<?php
    $title = 'Counceling Approval Schedule';
    $page = 'ca_appoint_sched';
    include_once('../includes/header.php');
?>
    <div class="content">
        <div class="approv_content">
            <div class="title">
                <h1>Approval Schedule</h1>
                <hr>
            </div>
            <div class="list_approv">
                <h3 class="list_title">List</h3>
                <table class="display_approv">
                    <tr> 
                        <th class="approv_title">Name</th>
                        <th class="approv_title">Course</th>
                        <th class="approv_title">Section</th>
                        <th class="approv_title">A.Y Code</th>
                        <th class="approv_title">Violation</th>
                        <th class="approv_title">Sanction</th>
                        <th class="approv_title">Date</th>
                    </tr>
                    <tr>
                        <td class="approv_data">data</td>
                        <td class="approv_data">data</td>
                        <td class="approv_data">data</td>
                        <td class="approv_data">data</td>
                        <td class="approv_data">data</td>
                        <td class="approv_data">data</td>
                        <td class="approv_data">data</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

</body>

</html>