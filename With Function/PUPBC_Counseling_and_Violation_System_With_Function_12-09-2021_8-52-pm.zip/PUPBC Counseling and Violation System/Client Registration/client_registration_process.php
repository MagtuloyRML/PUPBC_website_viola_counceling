<?php
    // for Connection.php
    include_once '../assets/connection/DBconnection.php';
    //pag sinubmit yung sa index.php
    if(isset($_POST['submit'])){
        $studnum = $_POST['stud_num'];
        $pass = $_POST['password'];
        $fullname = $_POST['stud_name'];
        $email = $_POST['stud_email'];
        $contactnumber = $_POST['stud_contact'];
        $guardian = $_POST['stud_guardian'];
        $guardiancontactnum = $_POST['guardian_contact'];
        //insert sa database
        $insert="INSERT INTO tbl_clients(stud_num, stud_pass, stud_name,
        stud_email, stud_contact, stud_guardian, guardian_contact) VALUES ('$studnum','$pass',
        '$fullname','$email','$contactnumber','$guardian','$guardiancontactnum')";
        if($conn->query($insert)){
            echo "Data Inserted";
            header ("Location: ../client login/index.php?signup=success");
            }else{
                echo "something is wrong" . $insert . $conn->error;
            }
    }
?> 