<?php
    $title = 'Maintenance';
    $page = 'v_maintenance';
    include_once('../includes/header.php');
?>

<?php
    $sub_page = 'vmain_stud_main';
    include('../includes/sub_nav.php');
?>
<?php 
    include 'assets/dbconnection.php';
    $query = "SELECT * from forprogram";

    $result1 = mysqli_query($conn, $query);
    $options = "";
    while($row2 = mysqli_fetch_array($result1))
    {
        $options = $options."<option>$row2[1]</option>";
    }

    if(isset($_POST['src'])){
        $searchq = $_POST['src'];
        $searchq = preg_replace("#[^0-9a-z]#i","",$searchq);
        
        $query = mysql_query("SELECT * FROM forstudents WHERE studNum LIKE '%$searchq%'
        OR lastName LIKE '%$searchq%'") 
        or die("Could not search");

    }
?>
            <div class="subcontent">
                <div class="sub_nav">
                    <a href="../Violation Maintenance Student Maintenance/" class="sub_nav_bttn_active">
                        Update Student
                    </a>
                    <a href="../Violation Maintenance Student Maintenance Section Year/" class="sub_nav_bttn">
                        Update Section/Year
                    </a>
                    <a href="../Violation Maintenance Student Maintenance Status/" class="sub_nav_bttn">
                        Update Status
                    </a>
                </div>
                <form>
                <!-- Update Student Tab -->
                <div class="sub_top_content">
                    <div class="student_input_group">

                        <div class="student_input">
                            <label for="#" class="label">Search:</label>
                            <input type="text" class="input_field" id="src" name="src" class="">
                            <input type="submit" value=">>" />
                        </div>
                        
                        <div class="student_select">
                            <label for="#" class="label">Curriculum: </label>
                            <select class="curri_selection" name="#" id="#">
                                <?php echo $options; ?>
                            </select>
                        </div>
                    </div>

                    <div class="student_main_bttn_group">
                        <a href="#" class="stud_bttn">
                            <i class="fas fa-save"></i>
                            Save
                        </a>
                    </div>
                </div>
                    

                <div class="stud_table_content">
                    <table class="stud_table">
                        <tr> 
                            
                            <th class="stud_title">Student #</th>
                            <th class="stud_title">Last Name</th>
                            <th class="stud_title">First Name</th>
                            <th class="stud_title">Middle Name</th>
                            <th class="stud_title">Curriculum</th>
                            <th class="stud_title">Section</th>
                            <th class="stud_title">Address</th>
                            <th class="stud_title">Gender</th>
                        </tr>
                        <?php
                        
                        $sched = $conn->query("SELECT * from forstudents");
						while($row = $sched->fetch_array()){
				    ?>
                        <tr>
                            
                            <td class="stud_data"> <?php echo $row['studNum']?> </td>
                            <td class="stud_data"> <?php echo $row['lastName']?> </td>
                            <td class="stud_data"> <?php echo $row['firstName']?> </td>
                            <td class="stud_data"> <?php echo $row['middleName']?> </td>
                            <td class="stud_data"> <?php echo $row['Course']?> </td>
                            <td class="stud_data"> <?php echo $row['Section']?> </td>
                            <td class="stud_data"> <?php echo $row['Address']?> </td>
                            <td class="stud_data"> <?php echo $row['Gender']?> </td>
                        </tr>
                        <?php
									}
				?>
                    </table>
                </div>

            </div>
      
        </div>
    </div>
</form>


</body>

</html>