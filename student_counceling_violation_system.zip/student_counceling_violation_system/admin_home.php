<DOCTYPE! html>
<html>
    <head>
        <title>HOME</title>
    </head>
    <body>
        <h1>Welcome!</h1>
    </body>
</html>