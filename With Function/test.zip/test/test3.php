<!DOCTYPE html>
<html>
    <head>
        <title>Appointment Scheduling Calendar</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
        <?php 
        include('connection.php');
        // para magather yung data
        $query = $conn->query("SELECT * FROM schedules ORDER BY id");
        ?>
        <script>
            $(document).ready(function(){
                var calendar = $('#calendar').fullCalendar({
                    editable: true,
                    header:{
                        left: 'prev, next today',
                        center: 'title',
                        right: 'month, agendaWeek, agendaDay'
                        },
                        /* Function para magamit data sa db and idisplay*/
                        events: 
                        [<?php while($row = $query -> fetch_object()) {?>
                        {
                            id : '<?php echo $row->id;?>', title: '<?php echo $row->title;?>',
                        start : '<?php echo $row->start_app;?>', end: '<?php echo $row->end_app;?>', 
                        }, 
                        <?php }?>],
                        selectable: false,
                        selectHelper: true,
                         /* may error pa dito 
                         select: function(start, end, allDay)
                        {
                            /* Function para mag insert ng data 
                            var title = prompt("Enter Event Title");
                            if(title)
                            {
                                var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                                var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
                                $.ajax(
                                {
                                url:"insert.php",
                                type:"POST",
                                data:{title:title, start:start, end:end},
                                success:function(data)
                                    {
                                    calendar.fullCalendar('refetchEvents');
                                    alert("Added Successfully");
                                    window.location.replace("test3.php");
                                    }
                                }
                            }
                        }, */

                });
            });
        </script>
    </head>
    <body>
        <br />
        <h2 align="center"><a href="#">Appointment Scheduling calendar</a></h2>
        <br />
        <div class="container">
            <div id="calendar">
            </div>
        
        </div>

    </body>
</html>