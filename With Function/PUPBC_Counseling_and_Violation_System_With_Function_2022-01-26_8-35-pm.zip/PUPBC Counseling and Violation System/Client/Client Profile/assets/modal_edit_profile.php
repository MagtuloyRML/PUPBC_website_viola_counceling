    <!---Modal/ Pop up-->
    <div class="modal_bg" id="modal_edit_prof">
        <div class="modal prof_pic_edit">
            <div class="title_bar">
                <P>Edit Profile Info</P>
                <a href="#" class="modal_title_bttn" id="close_modal0"><i class="fas fa-times-circle"></i></a>
            </div>
            
            <!--<form>-->
                <!-- INPUTING THE DATA FROM WEB PAGE & CALLING THE INSERT FUNCTION FROM ANOTHER PHP FILE -->
                <div class="modal_content">
                    
                    
                </div>

                <div class="footer_modal_bttn">
                    <a  class="modal_foot_bttn" type="submit" ><i class="fas fa-save"></i> Save</a>
                    <a  id="close_modal9" class="modal_foot_bttn"><i class="fas fa-sign-out-alt"></i> Exit</a>
                </div>

            <!--</form>-->
           
        </div>
    </div>
