    <!---Modal/ Pop up-->
    <div class="modal_upload_bg" id="modal_upload_violation">
        <div class="modal_upload">
            <div class="title_bar">
                <p>Upload Preview</p>
                <a href="#" class="modal_title_bttn" id="close_modal0" ><i class="fas fa-times-circle"></i></a>
            </div>
            <!--<form>-->
                    <div class="modal_content">
                        <div class="preview_table_content">
                            <table class="preview_table">
                                <tr> 
                                    <th class="preview_title"> </th>
                                    <th class="preview_title">Violation</th>
                                    <th class="preview_title">Sanction</th>
                                </tr>
                                <tr>
                                    <td class="preview_data"> </td>
                                    <td class="preview_data"> </td>
                                    <td class="preview_data"> </td>
                                </tr>
                            </table>
                        </div>
                   
                    </div>
                <div class="footer_modal_input">
                    <div class="file_input">
                        <label for="#" class="label">File Path: </label>
                        <input type="text" class="input_field" id="#" name="#" class="">
                        <a href="#" class="file_bttn"><i class="fas fa-folder-open"></i> Find File</a>
                    </div>
                    <div class="file_input">
                        <label for="#" class="label">Sheet: </label>
                        <input type="text" class="input_field" id="#" name="#" class="">
                        <a href="#" class="file_bttn"><i class="fas fa-spinner"></i> Load</a>
                    </div>
                </div>

                <div class="footer_modal_bttn">
                    <a href="#" class="modal_foot_bttn"><i class="fas fa-upload"></i>Upload</a>
                    <a href="#" id="close_modal9" class="modal_foot_bttn"><i class="fas fa-sign-out-alt"></i> Exit</a>
                </div>
                <!--</form>-->
            
        </div>
    </div>

    <script src="assets/js/modal_upload_violation.js"></script>