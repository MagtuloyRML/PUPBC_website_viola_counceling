<?php
    $title = 'Profile';
    $page = 'client_profile';
    include_once('../includes/header.php');
?>
    <div class="content">
        <div class="profile">
            <button class="acc_bttn"><i class="fas fa-user-cog"></i></button>
            <p>Profile Info</p>
            <div class="profile_info">
                <div class="profile_pic">
                    <form action="#">
                        <!--lagayan ng profile pic-->
                        <img class="prof_pic" src="#" alt="Profile Pic">
                        <button class="pic_bttn"><i class="fas fa-camera"></i> Profile Piture</button>
                    </form>
                </div>

                <div class="profile_info">
                    <form action="#">
                        <!--Edit nyo nalang yun needed information dito-->
                        <div class="input-container">
                            <i class="fa fa-user icon"></i>
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <i class="fa fa-user icon"></i>
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <i class="fa fa-user icon"></i>
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <i class="fa fa-user icon"></i>
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <i class="fa fa-user icon"></i>
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                    </form>
                </div>
            </div>

            <div class="counceling_records_content">
                <h3>Counceling Records</h3>
                <table class="cr_record">
                    <tr> 
                        <th class="cr_title">Counceling Num.</th>
                        <th class="cr_title">Title Counceling</th>
                        <th class="cr_title">Date</th>
                        <th class="cr_title">Monitored by:</th>
                        <th class="cr_title">Status</th>
                    </tr>
                    <tr>
                        <td class="cr_data">NO DATA AVAILABLE</td>
                        <td class="cr_data">NO DATA AVAILABLE</td>
                        <td class="cr_data">NO DATA AVAILABLE</td>
                        <td class="cr_data">NO DATA AVAILABLE</td> 
                        <td class="cr_data">NO DATA AVAILABLE</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    
</body>

</html>