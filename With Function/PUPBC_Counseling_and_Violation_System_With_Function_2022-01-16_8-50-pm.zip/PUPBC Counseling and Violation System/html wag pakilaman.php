<html>
<head>
</head>
<body>
<input type="file" id="fileUpload" />
<input type="button" id="upload" value="Upload" onclick="UploadProcess()" />
<br/>

<div id="ExcelTable"></div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.13.5/xlsx.full.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.13.5/jszip.js"></script>
<script type="text/javascript">
    function UploadProcess() {
        //Reference the FileUpload element.
        var fileUpload = document.getElementById("fileUpload");
 
        //Validate whether File is valid Excel file.
        var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.xls|.xlsx)$/;
        if (regex.test(fileUpload.value.toLowerCase())) {
            if (typeof (FileReader) != "undefined") {
                var reader = new FileReader();
 
                //For Browsers other than IE.
                if (reader.readAsBinaryString) {
                    reader.onload = function (e) {
                        GetTableFromExcel(e.target.result);
                    };
					 reader.readAsBinaryString(fileUpload.files[0]);
                } else {
                    //For IE Browser.
                    reader.onload = function (e) {
                        var data = "";
                        var bytes = new Uint8Array(e.target.result);
                        for (var i = 0; i < bytes.byteLength; i++) {
                            data += String.fromCharCode(bytes[i]);
                        }
                        GetTableFromExcel(data);
                    };
                    reader.readAsArrayBuffer(fileUpload.files[0]);
                }
            } else {
                alert("This browser does not support HTML5.");
            }
        } else {
            alert("Please upload a valid Excel file.");
        }
    };
    function GetTableFromExcel(data) {
        //Read the Excel File data in binary
		var workbook = XLSX.read(data, {
            type: 'binary'
        });
 
        //get the name of First Sheet.
        var Sheet = workbook.SheetNames[0];
 
        //Read all rows from First Sheet into an JSON array.
        var excelRows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[Sheet]);
 
        //Create a HTML Table element.
        var myTable  = document.createElement("table");
        myTable.border = "1";
 
        //Add the header row.
        var row = myTable.insertRow(-1);
 
        //Add the header cells.
        var headerCell = document.createElement("TH");
		headerCell.innerHTML = "StudentNumber";
        row.appendChild(headerCell);
 
        headerCell = document.createElement("TH");
        headerCell.innerHTML = "Name";
        row.appendChild(headerCell);
 
 
        //Add the data rows from Excel file.
        for (var i = 0; i < excelRows.length; i++) {
            //Add the data row.
            var row = myTable.insertRow(-1);
 
            //Add the data cells.
            var cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].StudentNumber;
 
            cell = row.insertCell(-1);
            cell.innerHTML = excelRows[i].Name;
 
            
        }
        
 
        var ExcelTable = document.getElementById("ExcelTable");
        ExcelTable.innerHTML = "";
        ExcelTable.appendChild(myTable);
    };
</script>
</body>
</html>

<?php

use PhpOffice\PhpSpreadsheet\Calculation\TextData\Text;

include ("../../../assets/PHPSpreedsheet/vendor/autoload.php");

$connect = new PDO("mysql:host=localhost;dbname=studentviolation_db", "root", "");

if($_FILES["file_path"]["name"] != '')
{
    $allowed_extension = array('xls', 'xlsx');
    $file_array = explode(".", $_FILES["file_path"]["name"]);
    $file_extension = end($file_array);

    if(in_array($file_extension, $allowed_extension)){

        $file_name = time() . '.' . $file_extension;
        move_uploaded_file($_FILES['file_path']['tmp_name'], $file_name);
        $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);

        $spreadsheet = $reader->load($file_name);

        unlink($file_name);

        $data = $spreadsheet->getActiveSheet()->toArray();
        
        foreach($data as $row)
        {
            $insert_data = array(
                ':pcode'  => $row[0],
                ':description'  => $row[1]
            );
            $pCoded = $row[0];
            $pdescription  = $row[1];


            $checkExistingCode = "SELECT courseCode, courseDescription FROM forprogram WHERE courseCode = :pcoded ";
            $query_result = $connect->prepare($checkExistingCode);
            $query_result->bindValue(':pcoded', $pCoded);
            $query_result->execute();
            $rowResult = $query_result->fetch(PDO::FETCH_ASSOC);


            if ($rowResult) {
                $update_data = "
                UPDATE forprogram
                SET courseCode = :pcode, 
                courseDescription = :description
                WHERE courseCode = :pcode ";
                $updatestatement = $connect->prepare($update_data);
                $updatestatement->execute($insert_data);
            }
            else{
                $query = "
                INSERT INTO forprogram
                (courseCode, courseDescription) 
                VALUES (:pcode, :description)
                ";

                $statement = $connect->prepare($query);
                $statement->execute($insert_data);
            }
            
        }
        $message = '<div class="alert alert-success">Data Imported Successfully</div>';

    }
    else{
        $message = '<div class="alert alert-danger">Only .xls or .xlsx file allowed</div>';
    }
}
else
{
 $message = '<div class="alert alert-danger">Please Select File</div>';
}

echo $message;


for($dataRow=2; $dataRow <=count($data); $dataRow++){
    foreach($data as $row)
    {
        $insert_data = array(
            ':pcode'  => $row[0],
            ':description'  => $row[1]
        );
        $pCoded = $row[0];
        $pdescription  = $row[1];


        $checkExistingCode = "SELECT courseCode, courseDescription FROM forprogram WHERE courseCode = :pcoded ";
        $query_result = $connect->prepare($checkExistingCode);
        $query_result->bindValue(':pcoded', $pCoded);
        $query_result->execute();
        $rowResult = $query_result->fetch(PDO::FETCH_ASSOC);


        if ($rowResult) {
            $update_data = "
            UPDATE forprogram
            SET courseCode = :pcode, 
            courseDescription = :description
            WHERE courseCode = :pcode ";
            $updatestatement = $connect->prepare($update_data);
            $updatestatement->execute($insert_data);
        }
        else{
            $query = "
            INSERT INTO forprogram
            (courseCode, courseDescription) 
            VALUES (:pcode, :description)
            ";

            $statement = $connect->prepare($query);
            $statement->execute($insert_data);
        }
        
    }
}
?>

