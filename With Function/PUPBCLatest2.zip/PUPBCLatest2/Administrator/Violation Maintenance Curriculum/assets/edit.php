<?php

include_once 'dbconnection.php';
$courseCode = $_GET['courseCode'];

$query = mysqli_query($conn, "SELECT * FROM `forprogram` WHERE courseCode = '$courseCode'");
$row = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>EDIT FORM</title>
</head>
<body>
    <h2>Edit</h2>
    <form method="POST" action="update.php?courseCode=<?php echo $courseCode; ?>">

    <label>Course Code: </label><input type="text" value="<?php echo $row['courseCode'];?>" name="courseCode">
    <label>Course Description: </label><input type="text" value="<?php echo $row['courseDescription'];?>" name="courseDescription">
    <input type="submit" name="submit">
    <a href="index.php">Back</a>
</body>
</html>

