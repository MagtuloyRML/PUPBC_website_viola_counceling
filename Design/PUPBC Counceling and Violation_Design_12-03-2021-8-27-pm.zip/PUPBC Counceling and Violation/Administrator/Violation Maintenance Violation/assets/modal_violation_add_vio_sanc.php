    <!---Modal/ Pop up-->
    <div class="modal_bg violation" id="modal_add_viola_input">
        <div class="modal">
            <div class="title_bar">
                <P>Creating Violation</P>
                <a href="#" class="modal_title_bttn" id="close_modal"><i class="fas fa-times-circle"></i></a>
            </div>
            <!--<form>-->
                <div class="modal_content">
                    <div class="modal_add_violation">
                        <label for="#">Violation:</label>
                        <input type="text" class="input_field" id="#" name="#" class="">
                    </div>
                    
                </div>

                <div class="footer_modal_bttn">
                    <a href="#" class="modal_foot_bttn"><i class="fas fa-save"></i> Save</a>
                    <a href="#" id="close_modal2" class="modal_foot_bttn"><i class="fas fa-sign-out-alt"></i> Exit</a>
                </div>

            <!--</form>-->
            
        </div>
    </div>

    <!---Modal/ Pop up-->
    <div class="modal_bg sanction" id="modal_add_sanc_input">
        <div class="modal">
            <div class="title_bar">
                <P>Creating Violation</P>
                <a href="#" class="modal_title_bttn" id="close_modal1"><i class="fas fa-times-circle"></i></a>
            </div>
            <!--<form>-->
                <div class="modal_content">
                    <div class="modal_add_sanction">
                        <div class="violation_select">
                            <label for="#">Violation:</label>
                            <select class="violation_selection" name="#" id="#">
                                <option value="#"> </option>
                                <option value="#"> </option>
                            </select>
                        </div>
                        
                        <div class="sanction_input">
                            <label for="#">Sanction:</label>
                            <input type="text" class="input_field" id="#" name="#" class="">
                        </div>
                        
                    </div>
                    
                </div>

                <div class="footer_modal_bttn">
                    <a href="#" class="modal_foot_bttn"><i class="fas fa-save"></i> Save</a>
                    <a href="#" id="close_modal3" class="modal_foot_bttn"><i class="fas fa-sign-out-alt"></i> Exit</a>
                </div>

            <!--</form>-->
            
        </div>
    </div>

    <script src="assets/js/modal_violation_add_vio.js"></script>
    <script src="assets/js/modal_violation_add_sanc.js"></script>