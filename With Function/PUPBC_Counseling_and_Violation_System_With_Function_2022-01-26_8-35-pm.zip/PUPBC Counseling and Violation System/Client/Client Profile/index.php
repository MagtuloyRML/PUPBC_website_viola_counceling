<?php
    $title = 'Profile';
    $page = 'client_profile';
    include_once('../includes/header.php');
?>
    <div class="content">
        <div class="profile">
            <button class="acc_bttn" id="openEditProfModal"><i class="fas fa-user-cog"></i></button>
            <p>Profile Info</p>
            <div class="profile_info">
                <div class="profile_pic">
                    <form action="#">
                        <img class="prof_pic" src="../../assets/user_profile_pic/default_user.jpg" alt="Profile Pic">
                        <button class="pic_bttn" id="openEditPicModal"><i class="fas fa-camera"></i> Profile Piture</button>
                    </form>
                </div>

                <div class="profile_content_info">
                    <form action="#">
                        <!--Edit nyo nalang yun needed information dito-->
                        <div class="input-container">
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                        <div class="input-container">
                            <label for="#">Name: </label>
                            <input class="input-field" id="#" type="text" placeholder="Admin Username" name="usrnm">
                        </div>
                    </form>
                </div>
            </div>

            <div class="counceling_records_content">
                <h4>Counceling Records</h4>
                <table class="cr_record">
                    <tr> 
                        <th class="cr_title">Counceling Num.</th>
                        <th class="cr_title">Title Counceling</th>
                        <th class="cr_title">Date</th>
                        <th class="cr_title">Monitored by:</th>
                        <th class="cr_title">Status</th>
                    </tr>
                    <tr>
                        <td class="cr_data">NO DATA AVAILABLE</td>
                        <td class="cr_data">NO DATA AVAILABLE</td>
                        <td class="cr_data">NO DATA AVAILABLE</td>
                        <td class="cr_data">NO DATA AVAILABLE</td> 
                        <td class="cr_data">NO DATA AVAILABLE</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <?php
        include('assets/modal_edit_picture.php')
    ?>
    <script src="assets/js/modal_edit_picture.js"></script>
    <?php
        include('assets/modal_edit_profile.php')
    ?>
    <script src="assets/js/modal_edit_profile.js"></script>
    
</body>

</html>