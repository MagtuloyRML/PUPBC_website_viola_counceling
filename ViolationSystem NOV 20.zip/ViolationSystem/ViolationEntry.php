<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Violation Entry</title>
</head>

<body>
    <h3> VIOLATION ENTRY </h3>

    <!-- SEARCH BOX -->
    <div class="searchBar">
        <table>
            <tr>
                <td>
                    <input type="text" placeholder="Search" class="search">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </td>
            </tr>
        </table>
    </div>
    <!-- STUDENT INFO -->
    <div class="studentInfo">
        <form action="" method="">
            <table>
                <p> Name: <input type="text" name="name" value=""> </p>
                <p> Course: <input type="text" name="course" value=""> </p>
                <p> Section: <input type="text" name="section" value=""> </p>
                <p> Aycode: <input type="text" name="aycode" value=""> </p>
                <p> Violation: <input type="text" name="violation" value=""> </p>
                <p> Sanction: <input type="text" name="sanction" value=""> </p>
                <p> Date: <input type="text" name="date" value=""> </p>
            </table>
        </form>
    </div>
    <!-- DATA MANIPULATION BUTTONS -->
    <table class="veButtons">
        <tr>
            <td><input type="button" name="save" value="Save"> </td>
            <td><input type="button" name="delete" value="Delete"> </td>
            <td><input type="button" name="update" value="Update"> </td>
            <td><input type="button" name="clear" value="Clear"> </td>

        </tr>
    </table>

    <!-- LIST / TABLE -->
    <div class="DisplayInfo">
        <table>
            <tr > 
                <th>Name</th>
                <th>Course</th>
                <th>Section</th>
                <th>A.Y Code</th>
                <th>Violation</th>
                <th>Sanction</th>
                <th>Date</th>
            </tr>
            <tr>
                <td>Name</td>
                <td>Course</td>
                <td>Section</td>
                <td>A.Y Code</td>
                <td>Violation</td>
                <td>Sanction</td>
                <td>Date</td>
            </tr>
        </table>

    </div>


</body>

</html>