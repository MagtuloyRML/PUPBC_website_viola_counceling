document.getElementById('upload_bttn').addEventListener('click', function() {
    document.querySelector('#modal_upload_curri').style.display = 'flex';
});
document.querySelector('#close_modal0').addEventListener('click', function(){
    document.querySelector('#modal_upload_curri').style.display = 'none';
});

document.querySelector('#close_modal9').addEventListener('click', function(){
    document.querySelector('#modal_upload_curri').style.display = 'none';
});


window.onclick = function(event) {
    if (event.target == document.querySelector('#modal_upload_curri')) {
        document.querySelector('#modal_upload_curri').style.display = "none";
    }
  };