<?php

include_once 'dbconnection.php';

$progCode = $_GET['progCode'];

$conn ->query("DELETE from forprogram WHERE progCode = '$progCode'");

header("Location: ../index.php?Deleted=success");



