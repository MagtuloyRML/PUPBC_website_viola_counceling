<DOCTYPE! html>
<html>
    <head>
        <title>Violation Record</title>
        <!-- DELETE NIYO NA LANG TO -->
        <style>
            #ay_filter{
                position: relative;
                bottom: 40px;
                left: 150px;
                width: 10em;

            }
            #print_record_btn{
                position: relative;
                left: 75em;
                bottom: 165px;
            }
        </style>
        
    </head>
    
    <body>
        <div>
            <div>
                <h1>Violation Record</h1>
                
            </div>
            <div>
                <form action="">
                    <label for=""><h3>Filter A.Y Record<h3></label>
                    <select name="ay_filter" id="ay_filter">
                        <option value=""></option>
                    </select>

                    <table>
                    <tr>
                        <th>Table NUM 1</th>
                        <th>Table NUM 1</th>
                        <th>Table NUM 1</th>
                        <th>Table NUM 1</th>
                        <th>Table NUM 1</th>

                    </tr>
                    <tr>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>

                    </tr>
                </table>
                <br>
                <table>
                    <tr>
                        <th>Table NUM 2</th>
                        <th>Table NUM 2</th>
                        <th>Table NUM 2</th>
                        <th>Table NUM 2</th>
                        <th>Table NUM 2</th>

                    </tr>
                    <tr>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>
                        <td>NO DATA AVAILABLE</td>

                    </tr>
                </table>
                <input type="submit" value ="Print Record" id="print_record_btn">
                </form>
            </div>

        </div>
    </body>
</html>