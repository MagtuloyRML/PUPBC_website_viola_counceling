<?php
    include_once 'dbconnection.php';


    $SQL = "SELECT * FROM forprogram;";
    $RESULT = mysqli_query($conn, $SQL);
    $resultchecker = mysqli_num_rows($RESULT);

    if ($resultchecker > 0) {

        while ($row = mysqli_fetch_assoc($RESULT)) {
            echo $row['courseCode'] ."<br>";
        }
    }
?>