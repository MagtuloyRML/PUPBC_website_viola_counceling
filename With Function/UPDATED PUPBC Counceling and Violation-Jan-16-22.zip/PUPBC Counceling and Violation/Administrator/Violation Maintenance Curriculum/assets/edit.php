<?php

include_once 'dbconnection.php';
$progCode = $_GET['progCode'];

$query = mysqli_query($conn, "SELECT * FROM `forprogram` WHERE progCode = '$progCode'");
$row = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>EDIT FORM</title>
</head>
<body>
    <h2>Edit</h2>
    <form method="POST" action="update.php?progCode=<?php echo $progCode; ?>">

    <label>Program Code: </label><input type="text" value="<?php echo $row['progCode'];?>" name="progCode">
    <label>Program Description: </label><input type="text" value="<?php echo $row['progDescription'];?>" name="progDescription">
    <input type="submit" name="submit">
    <a href="index.php">Back</a>
</body>
</html>

