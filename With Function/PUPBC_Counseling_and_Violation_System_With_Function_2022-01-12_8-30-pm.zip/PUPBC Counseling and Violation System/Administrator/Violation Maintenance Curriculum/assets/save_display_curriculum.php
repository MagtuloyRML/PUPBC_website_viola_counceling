<?php
    // INSERTING THE DATA TO DATA BASE
        include_once 'dbconnection.php';
    
    
        $cCode = $_POST['cCode'];
        $Description = $_POST['Description'];
        
        $sql = "INSERT INTO forprogram (courseCode, courseDescription) VALUES ('$cCode', '$Description')";
        $result = mysqli_query($conn, $sql);
    
        header("Location: ../index.php?save=success");
    
        if(!$result){
    
            echo "Failed";
        }
            
        

        
    

     
   
        
        
    

    