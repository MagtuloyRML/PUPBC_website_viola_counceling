<?php
include_once 'dbconnection.php';
$courseCode = $_GET['courseCode'];

$courseCode = $_POST['courseCode'];
$courseDescription = $_POST['courseDescription'];

mysqli_query($conn, "UPDATE `forprogram` SET courseCode='$courseCode',courseDescription= '$courseDescription' ");
header("Location: ../index.php?Updates=success");

