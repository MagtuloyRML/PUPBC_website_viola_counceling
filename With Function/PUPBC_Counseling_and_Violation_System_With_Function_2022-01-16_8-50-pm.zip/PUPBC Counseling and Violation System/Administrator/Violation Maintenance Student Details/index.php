<?php
    $title = 'Maintenance';
    $page = 'v_maintenance';
    include_once('../includes/header.php');
?>

<?php
    $sub_page = 'vmain_stud_details';
    include('../includes/sub_nav.php');
?>

            <div class="subcontent">
                <div class="title">
                    <h1>Student Details</h1>
                    <hr>
                </div>

                <div class="sd_bttn_group">
                    <a href="#" class="sd_bttn" id="upload_student_bttn">
                        <i class="fas fa-upload"></i>
                        Upload
                    </a>
                    <a href="#" class="sd_bttn" id="openModal_add_student">
                        <i class="fas fa-plus-square" ></i>
                        Create
                    </a>
                </div>

                <div class="sd_table_content">
                    <table class="sd_table" id="table">
                        <tr> 
                            <th class="stud_details_title">No.</th>
                            <th class="stud_details_title">Student Num</th>
                            <th class="stud_details_title">Last Name</th>
                            <th class="stud_details_title">First Name</th>
                            <th class="stud_details_title">Middle Name</th>
                            <th class="stud_details_title">Section</th>
                            <th class="stud_details_title" style="width: 33%;">Address</th>
                            <th class="stud_details_title">Gender</th>
                            <th class="stud_details_title">Program</th>
                        </tr>
                        <?php
                        include_once 'assets/dbconnection.php';
                        $SQL = $conn->query("SELECT studNum, lastName, firstName, middleName, Section, Address, Gender , progCode FROM forstudents");

                        if ($SQL->num_rows > 0) {
                            while ($row = $SQL->fetch_assoc()) {
                        ?>
                        <tr>
                            <td class="stud_details_data"></td>
                            <td class="stud_details_data"><?php echo $row['studNum']; ?> </td>
                            <td class="stud_details_data"><?php echo $row['lastName']; ?> </td>
                            <td class="stud_details_data"><?php echo $row['firstName']; ?> </td>
                            <td class="stud_details_data"><?php echo $row['middleName']; ?> </td>
                            <td class="stud_details_data"><?php echo $row['Section']; ?> </td>
                            <td class="stud_details_data"><?php echo $row['Address']; ?> </td>
                            <td class="stud_details_data"><?php echo $row['Gender']; ?> </td>
                            <td class="stud_details_data"><?php echo $row['progCode']; ?> </td>
                        </tr>
                        <?php
                            }
                        }
                        ?>
                    </table>
                </div>

            </div>
    </div>

    <script type="text/javascript">
        var table = document.getElementsByTagName('table')[0],
            rows = table.getElementsByTagName('tr'),
            text = 'textContent' in document ? 'textContent' : 'innerText';

        for (var i = 1, len = rows.length; i < len; i++) {
            rows[i].children[0][text] = i + ': ' + rows[i].children[0][text];
        }
    </script>

    <?php
        include_once('assets/modal_add_student.php');
    ?>

    <?php
        include_once('assets/modal_upload_student.php');
    ?>

</body>

</html>