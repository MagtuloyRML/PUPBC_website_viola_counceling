<?php

include_once 'dbconnection.php';

$courseCode = $_GET['courseCode'];

$conn ->query("DELETE from forprogram WHERE courseCode = '$courseCode'");

header("Location: ../index.php?Deleted=success");



