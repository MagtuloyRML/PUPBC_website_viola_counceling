<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!---icon--->
    <script src="https://kit.fontawesome.com/dcd5bb0e38.js" crossorigin="anonymous"></script> <!---icon--->

    <link href="assets/css/reg_style.css" rel="stylesheet">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Registration</title>
</head>
<body>
    <div class="select_container">

        <div class="selection">
            <a class="back_bttn" href="../Client Login/"><i class="fas fa-arrow-left"></i></a>

            <div class="reg_form">
                <div class="title">
                    <h1>Client Registration</h1>
                    <hr>
                </div>

                <form action="client_registration_process.php"method="POST">
                    <div class="input_group">
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Student Number" name="stud_num">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="password" placeholder="Student Password" name="password">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="password" placeholder="Confirm Password" name="password2">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Full Name" name="stud_name">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Email Address" name="stud_email">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Contact Number" name="stud_contact">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Guardian's Name" name="stud_guardian">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="input_container">
                            <input class="input-field" type="text" placeholder="Guardian's Contact Number" name="guardian_contact">
                            <i class="fas fa-lock"></i>
                        </div>
                    <div class="bttn_group">
                        <div class="reg_bttn">
                            <button type="submit" name="submit" class="selection_bttn"><i class="fas fa-sign-in-alt"></i> Sign Up</button>
                        </div>
                    </div>
               </form>
            </div>
            
            
            

        </div>

    </div>
    
</body>
</html>