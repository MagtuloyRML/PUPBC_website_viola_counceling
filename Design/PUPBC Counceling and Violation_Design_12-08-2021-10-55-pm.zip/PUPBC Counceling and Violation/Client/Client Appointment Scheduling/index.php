<?php
    $title = 'Appointment Scheduling';
    $page = 'client_app_sched';
    include_once('../includes/header.php');
?>
    <div class="content">
        <div class="appoint_form">
            <div class="title_content">
                <h3>Appointment Schedule</h3>
            </div>
            <div class="content_appoint">
                <form>
                    <div class="form_content">
                        <div class="input_container">
                            <label class="label" for="#">Student Name: </label>
                            <br>
                            <input class="input" type="text" id="#" name="name" value="">
                        </div>
                        <div class="input_container">
                            <label class="label" for="#">Student Name: </label>
                            <br>
                            <input class="input" type="text" id="#" name="name" value="">
                        </div>
                        <div class="input_container">
                            <label class="label" for="#">Student Name: </label>
                            <br>
                            <input class="input" type="text" id="#" name="name" value="">
                        </div>
                        <div class="input_container">
                            <label class="label" for="#">Student Name: </label>
                            <br>
                            <input class="input" type="text" id="#" name="name" value="">
                        </div>
                        <div class="input_container">
                            <label class="label" for="#">Student Name: </label>
                            <br>
                            <input class="input" type="text" id="#" name="name" value="">
                        </div>
                    </div>
                    <div class="form_action">
                        <a href="#" class="form_bttn">Appoint</a>
                    </div>
                </form>
            </div>
            
        </div>
    </div>


</body>

</html>