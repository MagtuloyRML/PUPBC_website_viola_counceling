-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 09, 2021 at 07:47 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentviolation_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `foracademicyear`
--

DROP TABLE IF EXISTS `foracademicyear`;
CREATE TABLE IF NOT EXISTS `foracademicyear` (
  `ayCode` varchar(50) NOT NULL,
  `yearFrom` year(4) NOT NULL,
  `yearTo` year(4) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  PRIMARY KEY (`ayCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foracademicyear`
--

INSERT INTO `foracademicyear` (`ayCode`, `yearFrom`, `yearTo`, `Semester`) VALUES
('2018, 2019 ', 2018, 2019, '1st');

-- --------------------------------------------------------

--
-- Table structure for table `foraycode`
--

DROP TABLE IF EXISTS `foraycode`;
CREATE TABLE IF NOT EXISTS `foraycode` (
  `ID` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forprogram`
--

DROP TABLE IF EXISTS `forprogram`;
CREATE TABLE IF NOT EXISTS `forprogram` (
  `courseCode` varchar(50) NOT NULL,
  `courseDescription` text NOT NULL,
  PRIMARY KEY (`courseCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forprogram`
--

INSERT INTO `forprogram` (`courseCode`, `courseDescription`) VALUES
('BSA', 'Bachelors of Science in Accounting'),
('BSIT', 'Bachelors of Science in Information Techonology'),
('BSC', 'Bachelors of Science in Computer'),
('BTS', 'army'),
('BSB', 'Bachelors of Science in Science');

-- --------------------------------------------------------

--
-- Table structure for table `forstudents`
--

DROP TABLE IF EXISTS `forstudents`;
CREATE TABLE IF NOT EXISTS `forstudents` (
  `studNum` varchar(50) NOT NULL,
  `lastName` text NOT NULL,
  `firstName` text NOT NULL,
  `middleName` text NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `Gender` text NOT NULL,
  `Status` varchar(50) NOT NULL,
  PRIMARY KEY (`studNum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forthesanctions`
--

DROP TABLE IF EXISTS `forthesanctions`;
CREATE TABLE IF NOT EXISTS `forthesanctions` (
  `Violations` text NOT NULL,
  `Sanctions` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fortheviolations`
--

DROP TABLE IF EXISTS `fortheviolations`;
CREATE TABLE IF NOT EXISTS `fortheviolations` (
  `Violations` text NOT NULL,
  PRIMARY KEY (`Violations`(150))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fortheviolations`
--

INSERT INTO `fortheviolations` (`Violations`) VALUES
('Cheating'),
('Bullying');

-- --------------------------------------------------------

--
-- Table structure for table `forviolationentries`
--

DROP TABLE IF EXISTS `forviolationentries`;
CREATE TABLE IF NOT EXISTS `forviolationentries` (
  `studNum` int(50) NOT NULL,
  `firstName` text NOT NULL,
  `courseCode` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `Violations` text NOT NULL,
  `Sanctions` text NOT NULL,
  `Date` date NOT NULL,
  `ayCode` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
