<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Violation Maintenance</title>
</head>

<body>
    <!-- BUTTONS ABOVE THE FORMS / TABLE -->
    <table>
        <td><input type="button" name="curriculum" value="Curriculum"> </td>
        <td><input type="button" name="violation" value="Violation"> </td>
        <td><input type="button" name="academicyear" value="Academic Year"> </td>
        <td><input type="button" name="students" value="Students"> </td>
        <td><input type="button" name="studentsmaintenance" value="Students Maintenance"> </td>


    </table>
    
    <!-- FORM BOX / SECTION -->
    <form class="form">

    </form>

    <style>
        .form{
        width: 1020px;
        height: 550px;
        border: 1px solid #666;
        }
    </style>
</body>

</html>