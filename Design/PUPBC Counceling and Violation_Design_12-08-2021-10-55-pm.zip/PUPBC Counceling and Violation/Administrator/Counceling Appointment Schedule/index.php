<?php
    $title = 'Counceling Apointment Dashboard';
    $page = 'ca_appoint_sched';
    include_once('../includes/header.php');
?>

</body>

</html>