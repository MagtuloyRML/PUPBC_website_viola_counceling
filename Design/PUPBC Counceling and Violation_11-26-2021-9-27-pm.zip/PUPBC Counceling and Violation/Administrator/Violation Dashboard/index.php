<?php
    $title = 'Violation Dashboard';
    $page = 'v_home';
    include_once('../includes/header.php');
?>
    <div class="body_container">
        <div class="container">
            <div class="title">
                <h1>DashBoard</h1>
                <hr>
            </div>
            <div class="divider">
                <!-- Date, Day, and Time day VISUALIZATION -->
                <div class="dash_content">
                    <h2>MON</h2>
                    <h3>Date</h3>
                    <p>12:30 pm</p>
                </div>
                <!-- A.Y CODE VISUALIZATION -->
                <div class="dash_content">
                    <h3><i class="fas fa-school"></i>Academic Year: </h3>
                    <p>00000000</p>
                </div>

                <!-- TOTAL NUMBERS OF STUDENT VISUAL DATA  -->
                <div class="dash_content">
                    <h3><i class="fas fa-user-graduate"></i>Total Student: </h3>
                    <p>00000000</p>
                </div>
                <!-- TOTAL NUMBERS OF VIOLATION VISUAL DATA  -->
                <div class="dash_content">
                    <h3><i class="fas fa-exclamation-circle"></i>Total Violation: </h3>
                    <p>00000000</p>
                </div>
            </div>
            
        </div>
    </div>
    
    
</body>
</html>
