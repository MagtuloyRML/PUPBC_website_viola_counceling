<!DOCTYPE html>
<html>
    <head>
        <title></title>
    </head>
    <body>
            <form action = "scheduleCheck.php" method = "POST">
                <!-- message if ever recorded or taken yung sched -->
                <?php if (isset($_GET['error'])) { ?>
                            <p class="error"><?php echo $_GET['error']; ?></p>
                        <?php } ?>

                        <?php if (isset($_GET['success'])) { ?>
                            <p class="success"><?php echo $_GET['success']; ?></p>
                        <?php } ?>

                <p>Fill up the following to appoint a Sched</p>
                <div class="reg_content">
                    <!---Text field for student registration
                    dagdagan mo nyo nalang ng info na need sa system--->
                    <div class="input-container">
                        <i class="fa fa-user icon"></i>
                        <input class="input-field" type="text" placeholder="Title" name="title" >
                    </div>
                    <div class="input-container">
                        <i class="fa fa-user icon"></i>
                        <p>Start Date and Time:</p>
                        <input class="input-field" type="datetime-local" name="start_app">
                    </div>
                    <div class="input-container">
                        <i class="fa fa-user icon"></i>
                        <p>End Date and Time:</p>
                        <input class="input-field" type="datetime-local" name="end_app" >
                    </div>
                <div class="sign_up">
                    <button type="submit" name="submit" class="btn">Submit</button>
                </div>
                
            </form>
    </body>
</html>