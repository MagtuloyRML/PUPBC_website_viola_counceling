<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Violation Form</title>
</head>

<body>
    <h2>Violation</h2>
    <div class="ViolationSanctionForm">
        <div class="violaionID">
            <table>
                <tr>
                    <th>Violation </th>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <input type="button" name="button" value="Add Violation">
                <input type="button" name="button" value="Delete a Violation">
                <input type="button" name="button" value="Proceed to Sanction">
            </table>
        </div>

        <div class="sanctionID">
            <table>
                <tr>
                    <th>Sanction</th>
                </tr>
                <tr>
                    <td></td>
                </tr>
                <input type="button" name="button" value="Add Sanction">
                <input type="button" name="button" value="Delete a Sanction">
            </table>
        </div>

    </div>
   
    <input type="button" name="upload" value="Upload">

    <style>
        .button {
            float: center;
        }

        table {
            width: 100%;
            margin: 30px auto;
            border-collapse: collapse;

        }

        .violaionID {
            float: left;
        }

        .sanctionID {
            float: right;
        }

        th {
            padding: 10px;
            width: 15%;
            border: 1px solid #666;

        }

        td {
            padding: 10px;

            height: 550px;
            border: 1px solid #666;

        }
    </style>


</body>

</html>